
The data contained in this zip archive is formatted as Comma-Separated Values (CSV).
This is a standard text file format that can be opened by many applications, such as 
Microsoft Excel. This Readme file describes the structure of the CSV file.

The CSV file has the following headings (or fields) in the first line:

    Fiscal Year - Fiscal year in which the results are reported or money disbursed.

    Country - The country in which the results are reported or money disbursed.

    Code - 2-Character ISO Country Code for country

    Category - The series of categories used to classify USAID's programmatic interventions 
               (i.e., Democracy and Governance, Economic Development, Education and Social 
               Services, Environment, Health, Humanitarian Assistance, Peace and Security, and 
               Program Management)

    Sector - The different components of the Categories. These correspond directly to the 
             results reported and money disbursed.

    Results Statement - The indicator against which results are reporting for the corresponding 
                        Sector.

    Disbursement ($) - The dollars spent for the corresponding Sector (or Category) during the 
                       year listed. If there is more than one Sector in a Category, disbursements 
                       are not reported at the Category level. This was done to avoid double 
                       counting if this data is imported into a spreadsheet. This information 
                       can be found on the website or by totaling the Sector disbursements for 
                       each country.

    Results - The number reported for the corresponding Results Statement for the year listed.

After the heading line, the remaining lines of the CSV file contain the data, sorted 
alphabetically by Year, Country, Category, Sector, and Results Statement. Lines 
containing disbursement amounts do not have data in the Results fields. Likewise, 
lines containing Results data do no not have data in the Disbursement fields.
